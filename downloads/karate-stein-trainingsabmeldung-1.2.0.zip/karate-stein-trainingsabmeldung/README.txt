Karate Stein – Trainingsabmeldung
===================================

Version 1.2.0

- Zeigt normalen Mitgliedern und Elternkonten direkt nach dem Login die nächsten Trainingseinheiten.
- Modernisierte, kompakte Kartenansicht im Stil der Karate-Stein-Homepage.
- Direkte Abmeldung für einzelne Termine mit optionalem organisatorischem Hinweis.
- Bereits gemeldete Abwesenheiten können zurückgenommen werden.
- Vollständige Terminübersicht unter „Meine Anwesenheit“.
- Trainer sehen vorab entschuldigte Mitglieder an der jeweiligen Einheit.
- Trainer- und Administratorkonten behalten ihre bisherige Startansicht.

Installation/Aktualisierung
---------------------------
Die ZIP-Datei in WordPress unter Plugins > Installieren > Plugin hochladen auswählen.
Bei einer vorhandenen Version „Aktuelle durch hochgeladene Version ersetzen“ bestätigen.
