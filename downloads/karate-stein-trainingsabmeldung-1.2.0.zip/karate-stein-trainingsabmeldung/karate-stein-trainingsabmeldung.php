<?php
/**
 * Plugin Name: Karate Stein – Trainingsabmeldung
 * Description: Zeigt normalen Mitgliedern direkt nach dem Login die nächsten Trainingseinheiten und ermöglicht die entschuldigte Abmeldung für einzelne Termine.
 * Version: 1.2.0
 * Author: Karate Dojo Stein
 * Requires at least: 6.6
 * Requires PHP: 8.2
 * Requires Plugins: karate-stein-core
 * Text Domain: karate-stein-trainingsabmeldung
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class KS_Training_Absence_Self_Service
{
    private const VERSION = '1.2.0';
    private const MAX_DAYS_AHEAD = 56;
    private const STATUS_EXCUSED = 'excused';
    private const STATUS_CANCELLED = 'cancelled';

    public static function boot(): void
    {
        add_filter('do_shortcode_tag', [self::class, 'enhance_member_portal'], 30, 4);
        add_filter('login_redirect', [self::class, 'login_redirect'], 25, 3);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets']);
        add_action('admin_post_ks_member_absence_report', [self::class, 'handle_report']);
        add_action('admin_post_ks_member_absence_cancel', [self::class, 'handle_cancel']);
        add_filter('query_vars', static function (array $vars): array {
            $vars[] = 'ks_absence';
            return $vars;
        });
    }


    private static function is_staff_account(WP_User $user): bool
    {
        return user_can($user, 'manage_options')
            || user_can($user, 'ks_manage_members')
            || user_can($user, 'ks_take_attendance');
    }

    public static function login_redirect(string $redirect_to, string $requested_redirect_to, $user): string
    {
        if (!$user instanceof WP_User || self::is_staff_account($user)) {
            return $redirect_to;
        }

        $is_member = (bool) array_intersect(['ks_member', 'ks_guardian'], (array) $user->roles)
            || user_can($user, 'ks_access_member_area');
        if (!$is_member) {
            return $redirect_to;
        }

        if ($requested_redirect_to !== '' && false === strpos($requested_redirect_to, '/mitglieder')) {
            return $redirect_to;
        }

        return add_query_arg('bereich', 'uebersicht', home_url('/mitglieder/'));
    }

    public static function activate(): void
    {
        global $wpdb;
        $table = self::absence_table();

        // The Karate-Stein core already owns this table on current sites. Never
        // reshape an existing production table from this small extension.
        if (!self::table_exists($table)) {
            $charset = $wpdb->get_charset_collate();
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta("CREATE TABLE {$table} (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                member_id bigint(20) unsigned NOT NULL,
                group_id bigint(20) unsigned NOT NULL,
                session_date date NOT NULL,
                status varchar(20) NOT NULL DEFAULT 'excused',
                note varchar(500) NOT NULL DEFAULT '',
                requested_by bigint(20) unsigned NOT NULL DEFAULT 0,
                requested_at datetime NOT NULL,
                cancelled_at datetime NULL,
                PRIMARY KEY  (id),
                UNIQUE KEY member_group_date (member_id,group_id,session_date),
                KEY group_date (group_id,session_date),
                KEY requested_by (requested_by)
            ) {$charset};");
        }

        update_option('ks_training_absence_self_service_version', self::VERSION, false);
    }

    private static function members_table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'ks_members';
    }

    private static function memberships_table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'ks_group_memberships';
    }

    private static function sessions_table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'ks_training_sessions';
    }

    private static function absence_table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'ks_member_absences';
    }

    private static function audit_table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'ks_member_audit';
    }

    private static function table_exists(string $table): bool
    {
        global $wpdb;
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
        return $found === $table;
    }

    /** @return array<int,object> */
    private static function account_members(int $user_id): array
    {
        global $wpdb;
        if ($user_id <= 0 || !self::table_exists(self::members_table())) {
            return [];
        }

        return (array) $wpdb->get_results($wpdb->prepare(
            'SELECT id, account_user_id, first_name, last_name, relationship, status
             FROM ' . self::members_table() . '
             WHERE account_user_id = %d AND status = %s
             ORDER BY first_name ASC, last_name ASC',
            $user_id,
            'active'
        ));
    }

    private static function user_owns_member(int $user_id, int $member_id): bool
    {
        global $wpdb;
        if ($user_id <= 0 || $member_id <= 0) {
            return false;
        }

        return (bool) $wpdb->get_var($wpdb->prepare(
            'SELECT id FROM ' . self::members_table() . ' WHERE id = %d AND account_user_id = %d AND status = %s LIMIT 1',
            $member_id,
            $user_id,
            'active'
        ));
    }

    /** @return int[] */
    private static function active_group_ids(int $member_id): array
    {
        global $wpdb;
        if ($member_id <= 0 || !self::table_exists(self::memberships_table())) {
            return [];
        }

        $ids = $wpdb->get_col($wpdb->prepare(
            'SELECT gm.group_id
             FROM ' . self::memberships_table() . ' gm
             INNER JOIN ' . $wpdb->posts . ' p ON p.ID = gm.group_id
             WHERE gm.member_id = %d
               AND gm.status = %s
               AND p.post_type = %s
               AND p.post_status = %s
             ORDER BY p.menu_order ASC, p.post_title ASC',
            $member_id,
            'active',
            'ks_training_group',
            'publish'
        ));

        return array_values(array_unique(array_filter(array_map('absint', (array) $ids))));
    }

    /** @return array<int,array<string,mixed>> */
    private static function schedule_rows(int $group_id): array
    {
        $rows = get_post_meta($group_id, '_ks_training_sessions', true);
        if (is_array($rows) && $rows) {
            return array_values(array_filter($rows, 'is_array'));
        }

        $weekdays = get_post_meta($group_id, '_ks_training_weekdays', true);
        if (!is_array($weekdays)) {
            $weekdays = $weekdays !== '' ? [$weekdays] : [];
        }
        $start = (string) get_post_meta($group_id, '_ks_training_start', true);
        $end = (string) get_post_meta($group_id, '_ks_training_end', true);
        $venue = (string) get_post_meta($group_id, '_ks_training_venue', true);
        $address = (string) get_post_meta($group_id, '_ks_training_address', true);

        $fallback = [];
        foreach ($weekdays as $weekday) {
            $day = absint($weekday);
            if ($day < 1 || $day > 7 || $start === '') {
                continue;
            }
            $fallback[] = [
                'day' => (string) $day,
                'start' => $start,
                'end' => $end,
                'venue' => $venue,
                'address' => $address,
            ];
        }
        return $fallback;
    }

    private static function normalise_time(string $time): string
    {
        if (preg_match('/^(\d{1,2}):(\d{2})/', trim($time), $matches)) {
            $hour = max(0, min(23, (int) $matches[1]));
            $minute = max(0, min(59, (int) $matches[2]));
            return sprintf('%02d:%02d', $hour, $minute);
        }
        return '';
    }

    private static function training_break(string $date, int $group_id): bool
    {
        foreach (['ks_is_school_holiday', 'ks_is_bavarian_school_holiday', 'ks_training_is_holiday'] as $function) {
            if (function_exists($function) && (bool) $function($date)) {
                return true;
            }
        }

        $break_options = ['ks_training_break_dates', 'ks_school_holidays', 'ks_training_holidays'];
        foreach ($break_options as $option_name) {
            $dates = get_option($option_name, []);
            if (is_string($dates)) {
                $dates = preg_split('/[\s,;]+/', $dates, -1, PREG_SPLIT_NO_EMPTY);
            }
            if (is_array($dates) && in_array($date, array_map('strval', $dates), true)) {
                return true;
            }
        }

        return (bool) apply_filters('ks_training_absence_is_break', false, $date, $group_id);
    }

    /** @return array<int,array<string,mixed>> */
    private static function concrete_sessions(array $group_ids, DateTimeImmutable $from, DateTimeImmutable $to): array
    {
        global $wpdb;
        if (!$group_ids || !self::table_exists(self::sessions_table())) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($group_ids), '%d'));
        $params = array_merge($group_ids, [$from->format('Y-m-d'), $to->format('Y-m-d')]);
        $sql = $wpdb->prepare(
            'SELECT id, group_id, session_date, starts_at, ends_at, venue, status
             FROM ' . self::sessions_table() . "
             WHERE group_id IN ({$placeholders})
               AND session_date BETWEEN %s AND %s
             ORDER BY session_date ASC, starts_at ASC",
            ...$params
        );

        return array_map(static function ($row): array {
            return [
                'session_id' => absint($row->id),
                'group_id' => absint($row->group_id),
                'date' => (string) $row->session_date,
                'start' => self::normalise_time((string) $row->starts_at),
                'end' => self::normalise_time((string) $row->ends_at),
                'venue' => (string) $row->venue,
                'status' => sanitize_key((string) $row->status),
                'source' => 'concrete',
            ];
        }, (array) $wpdb->get_results($sql));
    }

    /** @return array<int,array<string,mixed>> */
    private static function upcoming_sessions(int $member_id): array
    {
        $group_ids = self::active_group_ids($member_id);
        if (!$group_ids) {
            return [];
        }

        $timezone = wp_timezone();
        $now = new DateTimeImmutable('now', $timezone);
        $from = $now->setTime(0, 0);
        $to = $from->modify('+' . self::MAX_DAYS_AHEAD . ' days')->setTime(23, 59, 59);
        $sessions = [];
        $blocked = [];

        foreach (self::concrete_sessions($group_ids, $from, $to) as $session) {
            $key = $session['group_id'] . '|' . $session['date'] . '|' . $session['start'];
            if (in_array($session['status'], ['cancelled', 'canceled', 'abgesagt'], true)) {
                $blocked[$key] = true;
                continue;
            }
            $sessions[$key] = $session;
        }

        foreach ($group_ids as $group_id) {
            foreach (self::schedule_rows($group_id) as $row) {
                $weekday = absint($row['day'] ?? 0);
                $start = self::normalise_time((string) ($row['start'] ?? ''));
                $end = self::normalise_time((string) ($row['end'] ?? ''));
                if ($weekday < 1 || $weekday > 7 || $start === '') {
                    continue;
                }

                $date = $from;
                $shift = ($weekday - (int) $date->format('N') + 7) % 7;
                $date = $date->modify('+' . $shift . ' days');
                while ($date <= $to) {
                    $date_string = $date->format('Y-m-d');
                    $key = $group_id . '|' . $date_string . '|' . $start;
                    if (!isset($sessions[$key]) && !isset($blocked[$key]) && !self::training_break($date_string, $group_id)) {
                        $sessions[$key] = [
                            'session_id' => 0,
                            'group_id' => $group_id,
                            'date' => $date_string,
                            'start' => $start,
                            'end' => $end,
                            'venue' => sanitize_text_field((string) ($row['venue'] ?? '')),
                            'status' => 'scheduled',
                            'source' => 'schedule',
                        ];
                    }
                    $date = $date->modify('+7 days');
                }
            }
        }

        $sessions = array_values($sessions);
        $sessions = array_filter($sessions, static function (array $session) use ($now, $timezone): bool {
            try {
                $starts = new DateTimeImmutable($session['date'] . ' ' . ($session['start'] ?: '23:59'), $timezone);
                return $starts >= $now;
            } catch (Throwable) {
                return false;
            }
        });

        usort($sessions, static function (array $a, array $b): int {
            return strcmp($a['date'] . ' ' . $a['start'], $b['date'] . ' ' . $b['start']);
        });

        return array_slice(array_values($sessions), 0, 16);
    }

    /** @return array<string,object> */
    private static function active_absences(int $member_id): array
    {
        global $wpdb;
        if (!self::table_exists(self::absence_table())) {
            return [];
        }

        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT * FROM ' . self::absence_table() . '
             WHERE member_id = %d
               AND session_date >= %s
               AND cancelled_at IS NULL
               AND status <> %s',
            $member_id,
            current_time('Y-m-d'),
            self::STATUS_CANCELLED
        ));

        $map = [];
        foreach ((array) $rows as $row) {
            $map[(int) $row->group_id . '|' . (string) $row->session_date] = $row;
        }
        return $map;
    }

    private static function reason_label(string $reason): string
    {
        return match ($reason) {
            'krank' => 'Krankheit',
            'verhindert' => 'Verhindert',
            'schule_beruf' => 'Schule oder Beruf',
            'termin' => 'Anderer Termin',
            default => 'Sonstiger Grund',
        };
    }

    private static function encode_note(string $reason, string $note): string
    {
        $label = self::reason_label($reason);
        $note = trim(sanitize_text_field($note));
        if (function_exists('mb_substr')) {
            $note = mb_substr($note, 0, 300);
        } else {
            $note = substr($note, 0, 300);
        }
        return $note === '' ? $label : $label . ': ' . $note;
    }

    private static function audit(string $action, int $member_id, int $group_id, array $detail = []): void
    {
        global $wpdb;
        if (!self::table_exists(self::audit_table())) {
            return;
        }
        $wpdb->insert(
            self::audit_table(),
            [
                'action' => $action,
                'actor_user_id' => get_current_user_id(),
                'member_id' => $member_id,
                'object_type' => 'training_group',
                'object_id' => $group_id,
                'detail' => wp_json_encode($detail, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'created_at' => current_time('mysql'),
            ],
            ['%s', '%d', '%d', '%s', '%d', '%s', '%s']
        );
    }

    private static function redirect(string $message): never
    {
        wp_safe_redirect(add_query_arg(
            ['bereich' => 'anwesenheit', 'ks_absence' => sanitize_key($message)],
            home_url('/mitglieder/')
        ) . '#ks-training-absence');
        exit;
    }

    public static function handle_report(): void
    {
        if (!is_user_logged_in()) {
            auth_redirect();
        }
        check_admin_referer('ks_member_absence_report', 'ks_absence_nonce');

        $user_id = get_current_user_id();
        $member_id = absint($_POST['member_id'] ?? 0);
        $group_id = absint($_POST['group_id'] ?? 0);
        $date = sanitize_text_field(wp_unslash($_POST['session_date'] ?? ''));
        $start = self::normalise_time(sanitize_text_field(wp_unslash($_POST['starts_at'] ?? '')));
        $reason = sanitize_key(wp_unslash($_POST['reason'] ?? 'sonstiges'));
        $note = sanitize_text_field(wp_unslash($_POST['note'] ?? ''));

        if (!self::user_owns_member($user_id, $member_id)) {
            self::redirect('not_allowed');
        }

        $valid = false;
        foreach (self::upcoming_sessions($member_id) as $session) {
            if ((int) $session['group_id'] === $group_id && $session['date'] === $date && $session['start'] === $start) {
                $valid = true;
                break;
            }
        }
        if (!$valid) {
            self::redirect('invalid_session');
        }

        if (!in_array($reason, ['krank', 'verhindert', 'schule_beruf', 'termin', 'sonstiges'], true)) {
            $reason = 'sonstiges';
        }

        global $wpdb;
        $table = self::absence_table();
        $now = current_time('mysql');
        $existing_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE member_id = %d AND group_id = %d AND session_date = %s LIMIT 1",
            $member_id,
            $group_id,
            $date
        ));
        $data = [
            'member_id' => $member_id,
            'group_id' => $group_id,
            'session_date' => $date,
            'status' => self::STATUS_EXCUSED,
            'note' => self::encode_note($reason, $note),
            'requested_by' => $user_id,
            'requested_at' => $now,
            'cancelled_at' => null,
        ];

        $saved = $existing_id
            ? $wpdb->update($table, $data, ['id' => $existing_id])
            : $wpdb->insert($table, $data);

        if ($saved === false) {
            self::redirect('error');
        }

        self::audit('training_absence_reported', $member_id, $group_id, [
            'session_date' => $date,
            'starts_at' => $start,
            'reason' => $reason,
        ]);
        self::notify_trainers($member_id, $group_id, $date, $start, $data['note'], false);
        self::redirect('reported');
    }

    public static function handle_cancel(): void
    {
        if (!is_user_logged_in()) {
            auth_redirect();
        }
        check_admin_referer('ks_member_absence_cancel', 'ks_absence_nonce');

        $user_id = get_current_user_id();
        $absence_id = absint($_POST['absence_id'] ?? 0);
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            'SELECT a.*, m.account_user_id, m.first_name, m.last_name
             FROM ' . self::absence_table() . ' a
             INNER JOIN ' . self::members_table() . ' m ON m.id = a.member_id
             WHERE a.id = %d LIMIT 1',
            $absence_id
        ));

        if (!$row || (int) $row->account_user_id !== $user_id) {
            self::redirect('not_allowed');
        }

        $saved = $wpdb->update(
            self::absence_table(),
            [
                'status' => self::STATUS_CANCELLED,
                'cancelled_at' => current_time('mysql'),
            ],
            ['id' => $absence_id],
            ['%s', '%s'],
            ['%d']
        );
        if ($saved === false) {
            self::redirect('error');
        }

        self::audit('training_absence_cancelled', (int) $row->member_id, (int) $row->group_id, [
            'session_date' => (string) $row->session_date,
        ]);
        self::notify_trainers(
            (int) $row->member_id,
            (int) $row->group_id,
            (string) $row->session_date,
            '',
            '',
            true
        );
        self::redirect('cancelled');
    }

    private static function notify_trainers(
        int $member_id,
        int $group_id,
        string $date,
        string $start,
        string $note,
        bool $cancelled
    ): void {
        global $wpdb;
        $member = $wpdb->get_row($wpdb->prepare(
            'SELECT first_name, last_name FROM ' . self::members_table() . ' WHERE id = %d LIMIT 1',
            $member_id
        ));
        if (!$member) {
            return;
        }

        $emails = [];
        foreach ((array) get_post_meta($group_id, '_ks_training_trainer_users', true) as $trainer_id) {
            $trainer = get_user_by('id', absint($trainer_id));
            if ($trainer instanceof WP_User && is_email($trainer->user_email)) {
                $emails[] = $trainer->user_email;
            }
        }
        $emails = array_values(array_unique(array_filter($emails)));
        if (!$emails) {
            return;
        }

        $person = trim((string) $member->first_name . ' ' . (string) $member->last_name);
        $group = wp_strip_all_tags((string) get_the_title($group_id));
        $date_label = wp_date('l, j. F Y', strtotime($date . ' 12:00'));
        if ($cancelled) {
            $subject = 'Trainingsabmeldung zurückgenommen · ' . $group;
            $message = "{$person} hat die Abmeldung für {$date_label} zurückgenommen.";
        } else {
            $subject = 'Trainingsabmeldung · ' . $group;
            $message = "{$person} hat sich für {$date_label}" . ($start ? " um {$start} Uhr" : '') . " abgemeldet.\n\nGrund: {$note}";
        }
        $message .= "\n\nMitgliederbereich: " . home_url('/mitglieder/?bereich=trainer');
        wp_mail($emails, $subject, $message);
    }

    private static function notice(): string
    {
        $message = sanitize_key(wp_unslash($_GET['ks_absence'] ?? ''));
        $messages = [
            'reported' => ['success', 'Die Abmeldung wurde gespeichert und dem Trainerteam angezeigt.'],
            'cancelled' => ['success', 'Die Abmeldung wurde zurückgenommen.'],
            'invalid_session' => ['error', 'Diese Trainingseinheit ist nicht mehr verfügbar. Bitte die Seite neu laden.'],
            'not_allowed' => ['error', 'Diese Abmeldung darf mit diesem Konto nicht geändert werden.'],
            'error' => ['error', 'Die Abmeldung konnte nicht gespeichert werden. Bitte erneut versuchen.'],
        ];
        if (!isset($messages[$message])) {
            return '';
        }
        [$class, $text] = $messages[$message];
        return '<div class="ks-absence-notice is-' . esc_attr($class) . '" role="status">' . esc_html($text) . '</div>';
    }

    /** @return array<int,array{member:object,session:array<string,mixed>,absence:?object,sort:string}> */
    private static function account_session_items(array $members, int $limit = 0): array
    {
        $items = [];
        foreach ($members as $member) {
            $absences = self::active_absences((int) $member->id);
            foreach (self::upcoming_sessions((int) $member->id) as $session) {
                $key = (int) $session['group_id'] . '|' . (string) $session['date'];
                $items[] = [
                    'member' => $member,
                    'session' => $session,
                    'absence' => $absences[$key] ?? null,
                    'sort' => (string) $session['date'] . ' ' . (string) $session['start'],
                ];
            }
        }

        usort($items, static fn(array $a, array $b): int => strcmp($a['sort'], $b['sort']));
        return $limit > 0 ? array_slice($items, 0, $limit) : $items;
    }

    private static function render_session_card(
        object $member,
        array $session,
        ?object $absence,
        bool $show_person = false,
        string $context = 'full'
    ): string {
        $date_ts = strtotime($session['date'] . ' 12:00');
        $date_label = wp_date('l, j. F Y', $date_ts);
        $weekday = wp_date('D', $date_ts);
        $day = wp_date('j', $date_ts);
        $month = wp_date('M', $date_ts);
        $time = $session['start'] . ($session['end'] ? '–' . $session['end'] : '') . ' Uhr';
        $group_title = get_the_title((int) $session['group_id']);
        $person = trim((string) $member->first_name . ' ' . (string) $member->last_name);
        $is_today = $session['date'] === current_time('Y-m-d');
        $classes = ['ks-absence-session', 'ks-absence-session--' . sanitize_html_class($context)];
        if ($absence) {
            $classes[] = 'is-reported';
        }
        if ($is_today) {
            $classes[] = 'is-today';
        }

        ob_start();
        ?>
        <article class="<?php echo esc_attr(implode(' ', $classes)); ?>">
            <div class="ks-absence-date-tile" aria-label="<?php echo esc_attr($date_label); ?>">
                <span><?php echo esc_html($weekday); ?></span>
                <strong><?php echo esc_html($day); ?></strong>
                <small><?php echo esc_html($month); ?></small>
            </div>
            <div class="ks-absence-session-main">
                <div class="ks-absence-session-tags">
                    <?php if ($is_today) : ?><span class="ks-absence-tag is-today">Heute</span><?php endif; ?>
                    <?php if ($show_person) : ?><span class="ks-absence-tag is-person"><?php echo esc_html($person); ?></span><?php endif; ?>
                    <?php if ($absence) : ?><span class="ks-absence-tag is-excused">Abgemeldet</span><?php endif; ?>
                </div>
                <h3><?php echo esc_html((string) $group_title); ?></h3>
                <p class="ks-absence-session-time"><strong><?php echo esc_html($time); ?></strong><?php echo $session['venue'] ? '<span>' . esc_html((string) $session['venue']) . '</span>' : ''; ?></p>
                <?php if ($absence && $absence->note) : ?>
                    <p class="ks-absence-status"><?php echo esc_html((string) $absence->note); ?></p>
                <?php endif; ?>
            </div>
            <?php if ($absence) : ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="ks-absence-cancel-form">
                    <input type="hidden" name="action" value="ks_member_absence_cancel">
                    <input type="hidden" name="absence_id" value="<?php echo esc_attr((string) $absence->id); ?>">
                    <?php wp_nonce_field('ks_member_absence_cancel', 'ks_absence_nonce'); ?>
                    <button class="button ks-absence-secondary" type="submit">Abmeldung zurücknehmen</button>
                </form>
            <?php else : ?>
                <details class="ks-absence-details">
                    <summary class="button button-dark">Abmelden</summary>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="ks_member_absence_report">
                        <input type="hidden" name="member_id" value="<?php echo esc_attr((string) $member->id); ?>">
                        <input type="hidden" name="group_id" value="<?php echo esc_attr((string) $session['group_id']); ?>">
                        <input type="hidden" name="session_date" value="<?php echo esc_attr((string) $session['date']); ?>">
                        <input type="hidden" name="starts_at" value="<?php echo esc_attr((string) $session['start']); ?>">
                        <?php wp_nonce_field('ks_member_absence_report', 'ks_absence_nonce'); ?>
                        <div class="ks-absence-form-heading">
                            <span class="ks-absence-form-kicker">Einzeltermin</span>
                            <strong><?php echo esc_html($person); ?> · <?php echo esc_html($date_label); ?></strong>
                        </div>
                        <label>Grund
                            <select name="reason" required>
                                <option value="krank">Krankheit</option>
                                <option value="verhindert">Verhindert</option>
                                <option value="schule_beruf">Schule oder Beruf</option>
                                <option value="termin">Anderer Termin</option>
                                <option value="sonstiges">Sonstiger Grund</option>
                            </select>
                        </label>
                        <label>Kurzer Hinweis <span>optional</span>
                            <input name="note" maxlength="300" placeholder="Nur organisatorisch; keine Diagnose">
                        </label>
                        <button class="button button-primary" type="submit">Verbindlich abmelden</button>
                    </form>
                </details>
            <?php endif; ?>
        </article>
        <?php
        return (string) ob_get_clean();
    }

    private static function render_self_service(array $members): string
    {
        $total_items = self::account_session_items($members);
        ob_start();
        ?>
        <section id="ks-training-absence" class="ks-training-absence">
            <header class="ks-absence-head">
                <div>
                    <p class="eyebrow red">Dein Trainingsplan</p>
                    <h2>Kommende Trainings</h2>
                    <p>Hier siehst du deine nächsten Einheiten. Falls du verhindert bist, kannst du dich direkt beim jeweiligen Termin abmelden.</p>
                </div>
                <?php if ($total_items) : ?>
                    <div class="ks-absence-total" aria-label="<?php echo esc_attr((string) count($total_items)); ?> kommende Termine">
                        <strong><?php echo esc_html((string) count($total_items)); ?></strong>
                        <span>Termine</span>
                    </div>
                <?php endif; ?>
            </header>
            <?php echo self::notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <aside class="ks-absence-privacy" role="note"><strong>Hinweis:</strong> Ein kurzer organisatorischer Grund reicht aus. Bitte keine Diagnose oder Angaben zu Medikamenten eintragen.</aside>
            <?php
            $has_sessions = false;
            foreach ($members as $member) {
                $sessions = self::upcoming_sessions((int) $member->id);
                if (!$sessions) {
                    continue;
                }
                $has_sessions = true;
                $absences = self::active_absences((int) $member->id);
                $visible = array_slice($sessions, 0, 5);
                $more = array_slice($sessions, 5);
                ?>
                <section class="ks-absence-person">
                    <?php if (count($members) > 1) : ?>
                        <div class="ks-absence-person-head"><span>Training für</span><h3><?php echo esc_html(trim((string) $member->first_name . ' ' . (string) $member->last_name)); ?></h3></div>
                    <?php endif; ?>
                    <div class="ks-absence-session-list">
                        <?php
                        foreach ($visible as $session) {
                            $key = (int) $session['group_id'] . '|' . (string) $session['date'];
                            echo self::render_session_card($member, $session, $absences[$key] ?? null); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                        }
                        ?>
                    </div>
                    <?php if ($more) : ?>
                        <details class="ks-absence-more">
                            <summary>Weitere <?php echo esc_html((string) count($more)); ?> Termine anzeigen</summary>
                            <div class="ks-absence-session-list">
                                <?php
                                foreach ($more as $session) {
                                    $key = (int) $session['group_id'] . '|' . (string) $session['date'];
                                    echo self::render_session_card($member, $session, $absences[$key] ?? null); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                }
                                ?>
                            </div>
                        </details>
                    <?php endif; ?>
                </section>
                <?php
            }
            if (!$has_sessions) {
                echo '<div class="ks-absence-empty"><strong>Aktuell keine Termine</strong><p>Für deine aktiven Gruppen sind in den nächsten Wochen keine Trainingseinheiten hinterlegt.</p></div>';
            }
            ?>
            <footer class="ks-absence-footnote">Die Anzeige folgt dem aktuellen Trainingsplan. In den bayerischen Schulferien findet grundsätzlich kein Training statt.</footer>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    private static function quick_link(array $members = []): string
    {
        if (!$members) {
            return '';
        }
        $items = self::account_session_items($members, 4);
        ob_start();
        ?>
        <section class="ks-absence-dashboard" aria-labelledby="ks-next-training-title">
            <header class="ks-absence-dashboard-head">
                <div>
                    <p class="eyebrow red">Auf einen Blick</p>
                    <h2 id="ks-next-training-title">Deine nächsten Trainings</h2>
                    <p>Direkt nach dem Login – mit schneller Abmeldung für den einzelnen Termin.</p>
                </div>
                <a class="ks-absence-all-link" href="<?php echo esc_url(home_url('/mitglieder/?bereich=anwesenheit#ks-training-absence')); ?>">Alle Termine <span aria-hidden="true">→</span></a>
            </header>
            <?php echo self::notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php if ($items) : ?>
                <div class="ks-absence-dashboard-list">
                    <?php foreach ($items as $item) : ?>
                        <?php echo self::render_session_card( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                            $item['member'],
                            $item['session'],
                            $item['absence'],
                            count($members) > 1,
                            'overview'
                        ); ?>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <div class="ks-absence-empty"><strong>Aktuell keine kommenden Einheiten</strong><p>Sobald Termine für deine aktive Gruppe hinterlegt sind, erscheinen sie hier automatisch.</p></div>
            <?php endif; ?>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    private static function portal_area(string $output): string
    {
        if (isset($_GET['bereich']) && '' !== (string) $_GET['bereich']) {
            return sanitize_key(wp_unslash($_GET['bereich']));
        }

        if (preg_match('~<a\s+class="[^"]*is-active[^"]*"\s+href="[^"]*[?&](?:amp;)?bereich=([a-z0-9_-]+)[^"]*"~i', $output, $matches)) {
            return sanitize_key((string) $matches[1]);
        }

        return '';
    }

    private static function trainer_can_view_group(int $user_id, int $group_id): bool
    {
        if ($user_id <= 0 || $group_id <= 0) {
            return false;
        }
        if (user_can($user_id, 'manage_options') || user_can($user_id, 'ks_manage_members')) {
            return true;
        }
        if (!user_can($user_id, 'ks_take_attendance')) {
            return false;
        }

        $assigned = array_values(array_filter(array_map(
            'absint',
            (array) get_post_meta($group_id, '_ks_training_trainer_users', true)
        )));
        return in_array($user_id, $assigned, true);
    }

    private static function valid_date(string $date): bool
    {
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date, wp_timezone());
        $errors = DateTimeImmutable::getLastErrors();
        return $parsed instanceof DateTimeImmutable
            && (false === $errors || (0 === $errors['warning_count'] && 0 === $errors['error_count']))
            && $parsed->format('Y-m-d') === $date;
    }

    private static function trainer_absence_panel(): string
    {
        $user_id = get_current_user_id();
        $group_id = absint($_GET['gruppe'] ?? 0);
        $date = sanitize_text_field(wp_unslash($_GET['datum'] ?? ''));

        if (!$group_id || !self::valid_date($date) || !self::trainer_can_view_group($user_id, $group_id)) {
            return '';
        }

        global $wpdb;
        if (!self::table_exists(self::absence_table()) || !self::table_exists(self::members_table())) {
            return '';
        }

        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT a.id, a.member_id, a.note, a.requested_at, m.first_name, m.last_name
             FROM ' . self::absence_table() . ' a
             INNER JOIN ' . self::members_table() . ' m ON m.id = a.member_id
             WHERE a.group_id = %d
               AND a.session_date = %s
               AND a.cancelled_at IS NULL
               AND a.status <> %s
             ORDER BY m.last_name ASC, m.first_name ASC',
            $group_id,
            $date,
            self::STATUS_CANCELLED
        ));

        $group_title = wp_strip_all_tags((string) get_the_title($group_id));
        $date_label = wp_date('l, j. F Y', strtotime($date . ' 12:00'));
        ob_start();
        ?>
        <aside class="ks-trainer-absence-panel" role="status">
            <div class="ks-trainer-absence-heading">
                <div>
                    <p class="eyebrow red">Vorab gemeldete Abwesenheiten</p>
                    <h2><?php echo esc_html($group_title); ?> · <?php echo esc_html($date_label); ?></h2>
                </div>
                <strong class="ks-trainer-absence-count"><?php echo esc_html((string) count($rows)); ?></strong>
            </div>
            <?php if ($rows) : ?>
                <ul>
                    <?php foreach ($rows as $row) : ?>
                        <li>
                            <strong><?php echo esc_html(trim((string) $row->first_name . ' ' . (string) $row->last_name)); ?></strong>
                            <span>Entschuldigt<?php echo $row->note ? ' · ' . esc_html((string) $row->note) : ''; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else : ?>
                <p class="ks-trainer-absence-none">Für diese Einheit liegt aktuell keine Abmeldung vor.</p>
            <?php endif; ?>
        </aside>
        <?php
        return (string) ob_get_clean();
    }

    public static function enhance_member_portal(string $output, string $tag, array|string $attr, array $m): string
    {
        if ($tag !== 'ks_member_portal' || !is_user_logged_in()) {
            return $output;
        }

        $area = self::portal_area($output);
        $user = wp_get_current_user();
        $insert = '';

        if ('trainer' === $area) {
            $insert = self::trainer_absence_panel();
        } elseif (!self::is_staff_account($user)) {
            $members = self::account_members((int) $user->ID);
            if (!$members) {
                return $output;
            }

            if ('anwesenheit' === $area) {
                $insert = self::render_self_service($members);
            } elseif ('' === $area || 'uebersicht' === $area) {
                $insert = self::quick_link($members);
            }
        }

        if ('' === $insert) {
            return $output;
        }

        if (preg_match('~<div\\s+class="[^"]*\\bks-member-panel\\b[^"]*">~i', $output, $match, PREG_OFFSET_CAPTURE)) {
            $position = (int) $match[0][1] + strlen((string) $match[0][0]);
            return substr($output, 0, $position) . $insert . substr($output, $position);
        }

        return $insert . $output;
    }

    public static function enqueue_assets(): void
    {
        if (!is_page('mitglieder')) {
            return;
        }
        wp_register_style('ks-training-absence', false, [], self::VERSION);
        wp_enqueue_style('ks-training-absence');
        wp_add_inline_style('ks-training-absence', self::styles());
    }

    private static function styles(): string
    {
        return <<<'CSS'
:root{--ks-absence-red:#d91e28;--ks-absence-red-dark:#a40e18;--ks-absence-ink:#171315;--ks-absence-muted:#635b5e;--ks-absence-line:#ded5cf;--ks-absence-paper:#fff;--ks-absence-cream:#f8f5f1;--ks-absence-green:#176137}
.ks-training-absence,.ks-absence-dashboard{position:relative;isolation:isolate;margin:0 0 1.5rem;border:1px solid var(--ks-absence-line);border-radius:18px;background:var(--ks-absence-paper);box-shadow:0 14px 42px rgba(35,25,28,.07);overflow:hidden;scroll-margin-top:1rem}
.ks-absence-dashboard:before,.ks-training-absence:before{content:"";position:absolute;z-index:-1;inset:0 0 auto;height:5px;background:linear-gradient(90deg,var(--ks-absence-red),#f04a50 48%,var(--ks-absence-ink))}
.ks-absence-dashboard{padding:clamp(1rem,2.6vw,1.5rem)}
.ks-absence-dashboard-head,.ks-absence-head{display:flex;align-items:flex-start;justify-content:space-between;gap:1.25rem}
.ks-absence-dashboard-head{margin-bottom:1rem;padding-top:.25rem}
.ks-absence-dashboard-head h2,.ks-absence-head h2{margin:.12rem 0 .3rem;font-size:clamp(1.35rem,3vw,1.9rem);line-height:1.15}
.ks-absence-dashboard-head p,.ks-absence-head p{max-width:68ch;margin:.25rem 0;color:var(--ks-absence-muted)}
.ks-absence-all-link{display:inline-flex;align-items:center;gap:.35rem;flex:0 0 auto;padding:.65rem .8rem;border-radius:999px;color:var(--ks-absence-ink);font-weight:750;text-decoration:none;background:var(--ks-absence-cream)}
.ks-absence-all-link:hover,.ks-absence-all-link:focus{color:var(--ks-absence-red-dark);text-decoration:none}
.ks-absence-dashboard-list,.ks-absence-session-list{display:grid;gap:.75rem}
.ks-absence-dashboard-list{grid-template-columns:repeat(2,minmax(0,1fr))}
.ks-training-absence{padding:0 0 1rem}
.ks-absence-head{padding:clamp(1.1rem,3vw,1.7rem);background:linear-gradient(135deg,#fff 0%,#fff 62%,#fbf5f2 100%)}
.ks-absence-total{display:grid;place-items:center;flex:0 0 auto;min-width:5rem;padding:.65rem .75rem;border-radius:14px;background:var(--ks-absence-ink);color:#fff;text-align:center}
.ks-absence-total strong{font-size:1.55rem;line-height:1}.ks-absence-total span{margin-top:.2rem;font-size:.76rem;text-transform:uppercase;letter-spacing:.08em}
.ks-absence-privacy{margin:0 clamp(1rem,3vw,1.7rem) 1rem;padding:.78rem .95rem;border-radius:10px;background:var(--ks-absence-cream);color:#514a4d;font-size:.94rem}
.ks-absence-person{padding:0 clamp(1rem,3vw,1.7rem);margin-top:1.2rem}
.ks-absence-person-head{display:flex;align-items:baseline;gap:.5rem;margin:0 0 .7rem}.ks-absence-person-head span{color:var(--ks-absence-muted);font-size:.88rem}.ks-absence-person-head h3{margin:0;font-size:1.1rem}
.ks-absence-session{position:relative;display:grid;grid-template-columns:3.75rem minmax(0,1fr) auto;gap:.9rem;align-items:center;min-width:0;padding:.85rem;border:1px solid var(--ks-absence-line);border-radius:14px;background:#fff;transition:transform .16s ease,border-color .16s ease,box-shadow .16s ease}
.ks-absence-session:hover{transform:translateY(-1px);border-color:#cbbeb7;box-shadow:0 10px 26px rgba(35,25,28,.07)}
.ks-absence-session.is-reported{border-color:#a9cfb4;background:#f6fbf7}.ks-absence-session.is-today{border-color:#e6a8ab}
.ks-absence-date-tile{display:grid;place-items:center;align-self:stretch;min-height:4.2rem;padding:.35rem;border-radius:11px;background:var(--ks-absence-cream);color:var(--ks-absence-ink);text-align:center}
.ks-absence-session.is-today .ks-absence-date-tile{background:var(--ks-absence-red);color:#fff}
.ks-absence-date-tile span,.ks-absence-date-tile small{font-size:.72rem;font-weight:750;text-transform:uppercase;letter-spacing:.06em}.ks-absence-date-tile strong{font-size:1.55rem;line-height:1}
.ks-absence-session-main{min-width:0}.ks-absence-session-main h3{margin:.12rem 0 .28rem;font-size:1.04rem;line-height:1.25}.ks-absence-session-main p{margin:.1rem 0}
.ks-absence-session-tags{display:flex;flex-wrap:wrap;gap:.35rem;min-height:.1rem}.ks-absence-tag{display:inline-flex;padding:.22rem .48rem;border-radius:999px;background:#eee8e4;color:#514a4d;font-size:.69rem;font-weight:800;letter-spacing:.025em}.ks-absence-tag.is-today{background:#fee6e7;color:#8b1118}.ks-absence-tag.is-person{background:#eee9df;color:#4c453d}.ks-absence-tag.is-excused{background:#dff1e4;color:var(--ks-absence-green)}
.ks-absence-session-time{display:flex;flex-wrap:wrap;gap:.32rem .65rem;color:var(--ks-absence-muted);font-size:.92rem}.ks-absence-session-time strong{color:#332e30}.ks-absence-session-time span:before{content:"·";margin-right:.65rem;color:#aaa0a4}
.ks-absence-status{color:var(--ks-absence-green);font-size:.88rem}
.ks-absence-details{position:relative;margin:0}.ks-absence-details summary{list-style:none;white-space:nowrap;cursor:pointer}.ks-absence-details summary::-webkit-details-marker{display:none}.ks-absence-details[open]{grid-column:1/-1;width:100%;padding-top:.25rem}.ks-absence-details[open] summary{position:absolute;right:0;top:-4.55rem;opacity:.55}
.ks-absence-details form{display:grid;grid-template-columns:minmax(180px,.8fr) minmax(180px,1fr) minmax(230px,1.5fr) auto;gap:.75rem;align-items:end;padding:1rem;border:1px solid #d9cec7;border-radius:12px;background:var(--ks-absence-cream)}
.ks-absence-form-heading{display:grid;gap:.15rem;align-self:center}.ks-absence-form-kicker{color:var(--ks-absence-red-dark);font-size:.7rem;font-weight:850;text-transform:uppercase;letter-spacing:.08em}
.ks-absence-details label{display:grid;gap:.3rem;color:#383234;font-size:.86rem;font-weight:750}.ks-absence-details label span{font-weight:500;color:var(--ks-absence-muted)}
.ks-absence-details select,.ks-absence-details input{width:100%;min-height:42px;padding:.64rem .7rem;border:1px solid #cfc5bf;border-radius:8px;background:#fff;color:var(--ks-absence-ink)}
.ks-absence-details select:focus,.ks-absence-details input:focus{border-color:var(--ks-absence-red);box-shadow:0 0 0 2px rgba(217,30,40,.12);outline:0}
.ks-absence-cancel-form{margin:0}.ks-absence-secondary{white-space:nowrap;background:#fff!important;color:var(--ks-absence-green)!important;border:1px solid #9cc7a9!important}
.ks-absence-notice{margin:0 clamp(1rem,3vw,1.7rem) 1rem;padding:.85rem 1rem;border-radius:10px;font-weight:700}.ks-absence-dashboard>.ks-absence-notice{margin:0 0 1rem}.ks-absence-notice.is-success{background:#edf8f0;color:var(--ks-absence-green);border:1px solid #aad1b4}.ks-absence-notice.is-error{background:#fff0f0;color:#8b1118;border:1px solid #e2a6aa}
.ks-absence-empty{padding:1rem;border:1px dashed #cfc5bf;border-radius:12px;background:#fffdfb;color:var(--ks-absence-muted)}.ks-absence-empty strong{display:block;color:var(--ks-absence-ink)}.ks-absence-empty p{margin:.25rem 0 0}
.ks-absence-more{margin-top:.8rem}.ks-absence-more>summary{display:flex;align-items:center;justify-content:center;padding:.65rem;border-radius:10px;background:var(--ks-absence-cream);color:#514a4d;font-weight:750;cursor:pointer}.ks-absence-more[open]>summary{margin-bottom:.75rem}.ks-absence-footnote{display:block;margin:1rem clamp(1rem,3vw,1.7rem) 0;padding-top:.8rem;border-top:1px solid #eee7e2;color:var(--ks-absence-muted);font-size:.88rem}
.ks-trainer-absence-panel{margin:0 0 1.25rem;padding:1rem 1.1rem;border:1px solid var(--ks-absence-line);border-radius:14px;background:linear-gradient(135deg,#fff,#fbf6f3);box-shadow:0 10px 30px rgba(35,25,28,.06)}.ks-trainer-absence-heading{display:flex;align-items:center;justify-content:space-between;gap:1rem}.ks-trainer-absence-heading h2,.ks-trainer-absence-heading p{margin:.15rem 0}.ks-trainer-absence-count{display:grid;place-items:center;min-width:2.55rem;height:2.55rem;padding:0 .65rem;border-radius:999px;background:var(--ks-absence-red);color:#fff;font-size:1.08rem}.ks-trainer-absence-panel ul{display:grid;gap:.5rem;margin:.9rem 0 0;padding:0;list-style:none}.ks-trainer-absence-panel li{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;padding:.72rem .82rem;border-radius:10px;background:var(--ks-absence-cream)}.ks-trainer-absence-panel li span{color:#514a4d;text-align:right}.ks-trainer-absence-none{margin:.8rem 0 0;color:var(--ks-absence-muted)}
@media(max-width:900px){.ks-absence-dashboard-list{grid-template-columns:1fr}.ks-absence-details form{grid-template-columns:1fr 1fr}.ks-absence-form-heading{grid-column:1/-1}.ks-absence-details form .button{width:100%}}
@media(max-width:680px){.ks-absence-dashboard-head,.ks-absence-head{align-items:stretch;flex-direction:column}.ks-absence-all-link{align-self:flex-start}.ks-absence-total{display:flex;justify-content:center;gap:.5rem;min-width:0;width:max-content}.ks-absence-total span{margin:0}.ks-absence-session{grid-template-columns:3.35rem minmax(0,1fr)}.ks-absence-session>.ks-absence-cancel-form,.ks-absence-session>.ks-absence-details{grid-column:1/-1;width:100%}.ks-absence-details summary,.ks-absence-cancel-form .button{display:block;width:100%;text-align:center}.ks-absence-details[open] summary{position:static;margin-bottom:.6rem;opacity:1}.ks-absence-details form{grid-template-columns:1fr}.ks-absence-form-heading{grid-column:auto}.ks-absence-session-time{display:grid;gap:.1rem}.ks-absence-session-time span:before{content:none}.ks-trainer-absence-panel li{align-items:flex-start;flex-direction:column;gap:.15rem}.ks-trainer-absence-panel li span{text-align:left}}
CSS;
    }
}

register_activation_hook(__FILE__, [KS_Training_Absence_Self_Service::class, 'activate']);
KS_Training_Absence_Self_Service::boot();
