<?php
/**
 * Plugin Name: Karate Stein Personenprofile
 * Description: Wiederverwendbare Personenprofile für Gruppenanmeldungen: eigenes Profil auswählen, Kinder einmalig anlegen und anschließend ohne erneute Stammdateneingabe Gruppen hinzufügen.
 * Version: 1.0.0
 * Requires Plugins: karate-stein-core
 * Requires PHP: 8.1
 * Author: Karate Dojo Stein
 * Text Domain: karate-stein-personenprofile
 */

defined('ABSPATH') || exit;

final class KS_Personenprofile {
    private const VERSION = '1.0.0';

    public static function boot(): void {
        // Create a reusable participant profile from the member portal.
        add_action('admin_post_ks_member_add_person', [self::class, 'handle_add_person']);

        // The core handler still performs all group, capacity, wait-list and approval logic.
        // This early guard only prevents the old inline creation path from being used.
        add_action('admin_post_ks_member_apply', [self::class, 'require_saved_person'], 1);

        // Replace only the logged-in group application form after the core shortcode rendered it.
        add_filter('the_content', [self::class, 'replace_application_form'], 2000);
    }

    public static function require_saved_person(): void {
        if (!is_user_logged_in()) return;
        $member_id = absint($_POST['member_id'] ?? 0);
        if ($member_id > 0) return;

        self::redirect('choose_person', 0, self::posted_group_id(), self::posted_invitation());
    }

    public static function handle_add_person(): void {
        if (!is_user_logged_in()) auth_redirect();
        check_admin_referer('ks_member_add_person', 'ks_person_nonce');

        if (!class_exists('KS_Members')) {
            self::redirect('error');
        }

        $user_id = get_current_user_id();
        $first = sanitize_text_field(wp_unslash($_POST['participant_first_name'] ?? ''));
        $last = sanitize_text_field(wp_unslash($_POST['participant_last_name'] ?? ''));
        $birth_year = self::clean_birth_year($_POST['birth_year'] ?? 0);
        $grade = sanitize_text_field(wp_unslash($_POST['grade'] ?? ''));
        $relationship = sanitize_key(wp_unslash($_POST['relationship'] ?? 'child'));
        $relationship = in_array($relationship, ['self', 'child'], true) ? $relationship : 'child';
        $group_id = self::posted_group_id();
        $invitation = self::posted_invitation();

        if ($first === '' || $last === '' || !$birth_year) {
            self::redirect('missing', 0, $group_id, $invitation, $relationship);
        }

        global $wpdb;
        $table = KS_Members::members_table();

        // An account has at most one own participant profile. Children are separate profiles.
        if ($relationship === 'self') {
            $self_id = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table} WHERE account_user_id = %d AND relationship = %s AND status <> %s ORDER BY id ASC LIMIT 1",
                $user_id,
                'self',
                'deleted'
            ));
            if ($self_id) self::redirect('self_exists', $self_id, $group_id, $invitation, $relationship);
        }

        // Prevent accidental duplicate profiles when a parent submits the form twice.
        $existing_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table}
             WHERE account_user_id = %d AND first_name = %s AND last_name = %s
               AND birth_year = %d AND status <> %s
             ORDER BY id ASC LIMIT 1",
            $user_id,
            $first,
            $last,
            $birth_year,
            'deleted'
        ));
        if ($existing_id) self::redirect('person_exists', $existing_id, $group_id, $invitation, $relationship);

        $now = current_time('mysql');
        $data = [
            'account_user_id' => $user_id,
            'first_name'      => $first,
            'last_name'       => $last,
            'birth_year'      => $birth_year,
            'grade'           => $grade,
            'relationship'    => $relationship,
            'status'          => 'active',
            'created_at'      => $now,
            'updated_at'      => $now,
        ];
        $formats = ['%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s'];

        $inserted = $wpdb->insert($table, $data, $formats);
        if ($inserted === false) self::redirect('error', 0, $group_id, $invitation, $relationship);

        $member_id = (int) $wpdb->insert_id;
        self::audit_person_created($member_id, $relationship);
        self::redirect('person_added', $member_id, $group_id, $invitation, $relationship);
    }

    public static function replace_application_form(string $content): string {
        if (!is_user_logged_in() || !is_page('mitglieder') || !class_exists('KS_Members')) return $content;
        if (!str_contains($content, 'data-member-application')) return $content;

        $replacement = self::application_form();
        $updated = preg_replace_callback(
            '~<form\b[^>]*data-member-application[^>]*>.*?</form>~si',
            static fn(array $match): string => $replacement,
            $content,
            1
        );

        return is_string($updated) ? $updated : $content;
    }

    private static function application_form(): string {
        $members = KS_Members::members_for_account(get_current_user_id());
        $groups = KS_Members::assigned_groups(get_current_user_id(), true);
        $selected_member = absint($_GET['person'] ?? 0);
        if ($selected_member && !KS_Members::user_owns_member(get_current_user_id(), $selected_member)) {
            $selected_member = 0;
        }
        if (!$selected_member && count($members) === 1) $selected_member = (int) $members[0]->id;

        $selected_group = self::selected_group_id();
        $invitation = sanitize_text_field(wp_unslash($_GET['einladung'] ?? ''));
        $year = (int) wp_date('Y');
        $has_self = false;
        foreach ($members as $member) {
            if ((string) $member->relationship === 'self') {
                $has_self = true;
                break;
            }
        }

        $status = sanitize_key(wp_unslash($_GET['ks_person_status'] ?? ''));
        $kind = sanitize_key(wp_unslash($_GET['ks_person_kind'] ?? ''));
        $notice = self::notice($status, $kind);
        $open_profile_form = !$members || in_array($status, ['missing', 'error'], true);

        ob_start();
        ?>
        <div id="gruppenanmeldung" class="ks-person-profile-flow">
          <style>
            .ks-person-profile-flow{display:grid;gap:22px}
            .ks-person-profile-flow .ks-person-step{border:1px solid rgba(17,24,39,.12);border-radius:18px;padding:clamp(18px,3vw,28px);background:#fff;box-shadow:0 12px 34px rgba(17,24,39,.06)}
            .ks-person-profile-flow .ks-person-step h2{margin:.15em 0 .35em}
            .ks-person-profile-flow .ks-person-help{margin:.25rem 0 0;color:#596273;font-size:.94rem}
            .ks-person-profile-flow .ks-person-badge{display:inline-flex;align-items:center;padding:.24rem .58rem;border-radius:999px;background:#f2f4f7;font-size:.78rem;font-weight:700;margin-left:.4rem}
            .ks-person-profile-flow details.ks-person-step{padding:0;overflow:hidden}
            .ks-person-profile-flow details.ks-person-step>summary{cursor:pointer;list-style:none;padding:20px 24px;font-weight:800;display:flex;justify-content:space-between;align-items:center;gap:14px}
            .ks-person-profile-flow details.ks-person-step>summary::-webkit-details-marker{display:none}
            .ks-person-profile-flow details.ks-person-step>summary:after{content:'+';font-size:1.5rem;line-height:1}
            .ks-person-profile-flow details[open].ks-person-step>summary:after{content:'–'}
            .ks-person-profile-flow .ks-person-details{padding:0 24px 24px}
            .ks-person-profile-flow .ks-profile-list{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0 18px}
            .ks-person-profile-flow .ks-profile-list span{border:1px solid rgba(17,24,39,.12);border-radius:999px;padding:.45rem .72rem;background:#fafafa}
            @media(max-width:620px){.ks-person-profile-flow .ks-person-step{border-radius:14px}.ks-person-profile-flow details.ks-person-step>summary,.ks-person-profile-flow .ks-person-details{padding-left:18px;padding-right:18px}}
          </style>

          <?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

          <section class="ks-person-step">
            <div class="ks-member-form-head">
              <p class="eyebrow red">Gruppenanmeldung</p>
              <h2>Person auswählen und Gruppe hinzufügen</h2>
              <p>Die Personendaten werden nur einmal gespeichert. Danach wählst du hier nur noch die Person und die gewünschte Trainingsgruppe aus.</p>
            </div>

            <?php if ($selected_group): ?>
              <div class="ks-member-notice is-info" role="status">
                <strong><?php echo esc_html(get_the_title($selected_group)); ?></strong>
                <?php $group_note = (string) get_post_meta($selected_group, '_ks_member_signup_note', true); ?>
                <?php if ($group_note !== ''): ?><p><?php echo esc_html($group_note); ?></p><?php endif; ?>
              </div>
            <?php endif; ?>

            <?php if ($members): ?>
              <div class="ks-profile-list" aria-label="Gespeicherte Personen">
                <?php foreach ($members as $member): ?>
                  <span><?php echo esc_html(self::relationship_label((string) $member->relationship) . ': ' . $member->first_name . ' ' . $member->last_name); ?></span>
                <?php endforeach; ?>
              </div>

              <form class="ks-member-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" data-member-application>
                <input type="hidden" name="action" value="ks_member_apply">
                <?php wp_nonce_field('ks_member_apply', 'ks_member_nonce'); ?>
                <?php if ($invitation !== ''): ?><input type="hidden" name="group_invitation" value="<?php echo esc_attr($invitation); ?>"><?php endif; ?>
                <div class="ks-member-form-grid">
                  <label>Wer soll teilnehmen? *
                    <select required name="member_id">
                      <option value="">Person auswählen</option>
                      <?php foreach ($members as $member): ?>
                        <option value="<?php echo esc_attr((string) $member->id); ?>" <?php selected($selected_member, (int) $member->id); ?>>
                          <?php echo esc_html(self::relationship_label((string) $member->relationship) . ' – ' . $member->first_name . ' ' . $member->last_name); ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                    <span class="ks-person-help">Name, Geburtsjahr und Graduierung kommen aus dem gespeicherten Profil.</span>
                  </label>
                  <label>Welche Gruppe? *
                    <select required name="group_id">
                      <?php echo self::group_options($groups, $selected_group); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    </select>
                  </label>
                  <label class="is-wide">Hinweis an das Trainerteam, optional
                    <textarea name="application_note" rows="3" placeholder="Nur organisatorisch Relevantes; bitte keine Diagnosen oder ausführlichen Gesundheitsdaten."></textarea>
                  </label>
                </div>
                <button class="button button-primary" type="submit">Zur Gruppe hinzufügen</button>
              </form>
            <?php else: ?>
              <div class="ks-member-notice is-info" role="status"><strong>Noch keine Person angelegt.</strong><p>Lege unten einmalig dich selbst oder dein Kind an. Danach kannst du die Person jeder passenden Gruppe hinzufügen.</p></div>
            <?php endif; ?>
          </section>

          <details class="ks-person-step" <?php echo $open_profile_form ? 'open' : ''; ?>>
            <summary>
              <span><?php echo esc_html($has_self ? 'Kind einmalig anlegen' : 'Person einmalig anlegen'); ?></span>
              <span class="ks-person-badge">nur beim ersten Mal</span>
            </summary>
            <div class="ks-person-details">
              <p><?php echo esc_html($has_self ? 'Hier legst du ein Kind einmalig an. Das Profil steht anschließend dauerhaft in der Personenauswahl oben bereit.' : 'Lege zunächst dein eigenes Profil oder ein Kind an. Diese Daten müssen bei späteren Gruppenanmeldungen nicht erneut eingegeben werden.'); ?></p>
              <form class="ks-member-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="ks_member_add_person">
                <?php wp_nonce_field('ks_member_add_person', 'ks_person_nonce'); ?>
                <?php if ($selected_group): ?><input type="hidden" name="return_group_id" value="<?php echo esc_attr((string) $selected_group); ?>"><?php endif; ?>
                <?php if ($invitation !== ''): ?><input type="hidden" name="return_invitation" value="<?php echo esc_attr($invitation); ?>"><?php endif; ?>
                <?php if ($has_self): ?>
                  <input type="hidden" name="relationship" value="child">
                <?php endif; ?>
                <div class="ks-member-form-grid">
                  <?php if (!$has_self): ?>
                    <label>Profil für *
                      <select required name="relationship">
                        <option value="self">Mich selbst</option>
                        <option value="child">Mein Kind</option>
                      </select>
                    </label>
                  <?php endif; ?>
                  <label>Vorname *<input required name="participant_first_name" autocomplete="off"></label>
                  <label>Nachname *<input required name="participant_last_name" autocomplete="off"></label>
                  <label>Geburtsjahr *<input required type="number" min="<?php echo esc_attr((string) ($year - 100)); ?>" max="<?php echo esc_attr((string) $year); ?>" name="birth_year" inputmode="numeric"></label>
                  <label>Aktueller Kyu/Dan, optional<input name="grade" placeholder="z. B. 7. Kyu"></label>
                </div>
                <button class="button" type="submit"><?php echo esc_html($has_self ? 'Kind speichern' : 'Person speichern'); ?></button>
              </form>
            </div>
          </details>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    private static function group_options(array $groups, int $selected): string {
        $html = '<option value="">Gruppe auswählen</option>';
        foreach ($groups as $group) {
            $capacity = absint(get_post_meta($group->ID, '_ks_member_capacity', true));
            $active = KS_Members::count_group_members((int) $group->ID, 'active');
            $availability = $capacity > 0
                ? ($active >= $capacity ? ' · Warteliste' : ' · ' . max(0, $capacity - $active) . ' frei')
                : '';
            $html .= '<option value="' . esc_attr((string) $group->ID) . '" ' . selected($selected, (int) $group->ID, false) . '>'
                . esc_html($group->post_title . $availability) . '</option>';
        }
        return $html;
    }

    private static function selected_group_id(): int {
        $raw = sanitize_text_field(wp_unslash($_GET['gruppe'] ?? ''));
        if ($raw === '') return 0;
        $group = ctype_digit($raw)
            ? get_post((int) $raw)
            : get_page_by_path(sanitize_title($raw), OBJECT, 'ks_training_group');
        if (!$group instanceof WP_Post) return 0;
        if ($group->post_type !== 'ks_training_group' || $group->post_status !== 'publish') return 0;
        return get_post_meta($group->ID, '_ks_member_signup_enabled', true) === '1' ? (int) $group->ID : 0;
    }

    private static function posted_group_id(): int {
        $group_id = absint($_POST['group_id'] ?? $_POST['return_group_id'] ?? 0);
        if (!$group_id || get_post_type($group_id) !== 'ks_training_group' || get_post_status($group_id) !== 'publish') return 0;
        return $group_id;
    }

    private static function posted_invitation(): string {
        return sanitize_text_field(wp_unslash($_POST['group_invitation'] ?? $_POST['return_invitation'] ?? ''));
    }

    private static function clean_birth_year(mixed $value): int {
        $year = absint($value);
        $current = (int) wp_date('Y');
        return ($year >= $current - 100 && $year <= $current) ? $year : 0;
    }

    private static function relationship_label(string $relationship): string {
        return match ($relationship) {
            'self' => 'Ich selbst',
            'child' => 'Kind',
            default => 'Betreute Person',
        };
    }

    private static function notice(string $status, string $kind): string {
        $messages = [
            'person_added' => ['success', $kind === 'self' ? 'Dein Profil wurde einmalig angelegt. Du kannst es jetzt einer Gruppe hinzufügen.' : 'Das Kind wurde einmalig angelegt. Du kannst es jetzt einer oder mehreren Gruppen hinzufügen.'],
            'person_exists' => ['info', 'Diese Person war bereits angelegt und ist nun oben ausgewählt. Es wurde kein doppeltes Profil erstellt.'],
            'self_exists' => ['info', 'Dein eigenes Profil war bereits angelegt und ist nun oben ausgewählt.'],
            'choose_person' => ['error', 'Bitte zuerst eine gespeicherte Person auswählen.'],
            'missing' => ['error', 'Bitte Vorname, Nachname und ein gültiges Geburtsjahr angeben.'],
            'error' => ['error', 'Das Personenprofil konnte nicht gespeichert werden. Bitte die Seite neu laden und erneut versuchen.'],
        ];
        if (!isset($messages[$status])) return '';
        [$type, $text] = $messages[$status];
        return '<div class="ks-member-notice is-' . esc_attr($type) . '" role="status">' . esc_html($text) . '</div>';
    }

    private static function audit_person_created(int $member_id, string $relationship): void {
        if (!method_exists('KS_Members', 'audit_table')) return;
        global $wpdb;
        $wpdb->insert(KS_Members::audit_table(), [
            'action'        => 'member_profile_created',
            'actor_user_id' => get_current_user_id(),
            'member_id'     => $member_id,
            'object_type'   => 'member',
            'object_id'     => $member_id,
            'detail'        => wp_json_encode(['relationship' => $relationship], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at'    => current_time('mysql'),
        ], ['%s', '%d', '%d', '%s', '%d', '%s', '%s']);
    }

    private static function redirect(
        string $status,
        int $member_id = 0,
        int $group_id = 0,
        string $invitation = '',
        string $kind = ''
    ): never {
        $args = [
            'bereich' => 'gruppen',
            'ks_person_status' => sanitize_key($status),
        ];
        if ($member_id > 0) $args['person'] = $member_id;
        if ($group_id > 0) $args['gruppe'] = $group_id;
        if ($invitation !== '') $args['einladung'] = $invitation;
        if ($kind !== '') $args['ks_person_kind'] = sanitize_key($kind);
        wp_safe_redirect(add_query_arg($args, home_url('/mitglieder/')));
        exit;
    }
}

KS_Personenprofile::boot();
